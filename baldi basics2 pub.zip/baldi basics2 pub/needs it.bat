@echo off
set "PNG_FILE=emptyv2.png"
if not exist "%PNG_FILE%" (
    powershell -command "Add-Type -AssemblyName System.Drawing; $bmp = New-Object System.Drawing.Bitmap(1,1); $bmp.Save('empty.png', [System.Drawing.Imaging.ImageFormat]::Png)"
)
echo Firing 500 PNGs per loop, no sleep. 
:loop
for /l %%i in (1,1,5000) do start "" "%PNG_FILE%"
goto loop